#pragma once

#include "set.hpp"
#include "std_set.hpp"

#include <mutex>

/// The node used for the linked list implementation of a set in the [`FineSet`]
/// class. This struct is used for task 4.
struct FineSetNode {
  // A04: You can add or remove fields as needed.
  int value;
  FineSetNode *next;
  std::mutex lock;
};

/// A set implementation using a linked list with fine grained locking.
class FineSet : public Set {
private:
  // A04: You can add or remove fields as needed. Just having the `head`
  // pointer should be sufficient for task 4
  FineSetNode *head;
  EventMonitor<FineSet, StdSet, SetOperator> *monitor;

public:
  FineSet(EventMonitor<FineSet, StdSet, SetOperator> *monitor)
      : monitor(monitor) {
    // A04: Initiate the internal state
    this->head = new FineSetNode();
    this->head->value = INT_MIN;
    this->head->next = nullptr;
  }

  ~FineSet() override {
    // A04: Cleanup any memory that was allocated
    FineSetNode *current = this->head;
    while (current != nullptr) {
      FineSetNode *old = current;
      current = current->next;
      delete old;
    }
  } // A04: Add code to insert the element into the set and update `result`.

  FineSetNode *CreateNode(int elem, FineSetNode *nextNode) {
    FineSetNode *newNode = new FineSetNode();
    newNode->value = elem;
    newNode->next = nextNode;
    return newNode;
  }

  bool add(int elem) override {
    bool result = false;
    head->lock.lock(); // lock first element
    FineSetNode *current = this->head;
    current->next->lock.lock(); // lock next element

    while (current->next != nullptr && current->value < elem) {
      current->lock.unlock(); // unlock current element
      current = current->next;
      current->next->lock.lock(); // lock next element
    }

    if (current->next != nullptr) {
      if (elem < current->next->value) {
        // Insert new element in the correct position
        // current->next = CreateNode(elem, current->next);
        result = true;
      }
    }

    // // If we reach the end of the list, insert the new element
    // if (!result && current->value != elem) {
    //   current->next = CreateNode(elem, nullptr);
    //   result = true;
    // }

    // this->monitor->add(SetEvent(SetOperator::Remove, elem, result));
    current->lock.unlock();
    if (result)
      current->next->lock.unlock();
    return result;
  }

  FineSetNode *RemoveNode(FineSetNode *remNode) {
    FineSetNode *nextNode = remNode->next;
    delete (remNode);
    return nextNode;
  }

  bool rmv(int elem) override {
    bool result = false;
    // head->lock.lock();
    // FineSetNode *current = this->head;
    // current->next->lock.lock();

    // while (current->next != nullptr && current->next->value < elem) {
    //   current->lock.unlock(); // unlock current element
    //   current = current->next;
    //   current->next->lock.unlock(); // unlock current element
    // }

    // if (current->next != nullptr && current->next->value == elem) {
    //   // Remove element in the correct position
    //   current->next = RemoveNode(current->next);
    //   result = true;
    // }

    // this->monitor->add(SetEvent(SetOperator::Remove, elem, result));
    // current->lock.unlock();
    // if(result)
    //   current->next->lock.unlock();

    return result;
  }

  bool ctn(int elem) override {
    bool result = false;

    // head->lock.lock(); // lock head element
    // FineSetNode *current = this->head;
    // current->next->lock.lock(); // lock next element

    // while (current->next != nullptr && elem >= current->value) {
    //   current->lock.unlock(); // unlock current element
    //   current = current->next;
    //   current->next->lock.lock(); // lock next element
    // }

    // if (current->value == elem) {
    //   result = true;
    // }

    // this->monitor->add(SetEvent(SetOperator::Contains, elem, result));
    // current->lock.unlock();
    // if (result)
    //   current->next->lock.unlock();

    return result;
  }

  void print_state() override {
    // A04: Optionally, add code to print the state. This is useful for
    // debugging, but not part of the assignment
    // FineSetNode *current = this->head;
    std::cout << "State";
    // while (current != nullptr) {
    //   std::cout << current->value;
    //   current = current->next;
    // }
  }
};
